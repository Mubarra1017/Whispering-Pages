import type { Book } from "@shared/books";
import { addCartItem, cartSubtotal, setCartItemQuantity, type CartItem } from "@shared/cart";
import { createContext, useContext, useEffect, useMemo, useState, type ReactNode } from "react";

export type { CartItem } from "@shared/cart";

type StorefrontContextValue = {
  cart: CartItem[];
  wishlist: Book[];
  cartCount: number;
  subtotal: number;
  addToCart: (book: Book) => void;
  removeFromCart: (key: string) => void;
  updateQuantity: (key: string, quantity: number) => void;
  clearCart: () => void;
  toggleWishlist: (book: Book) => void;
  isWishlisted: (key: string) => boolean;
};

const StorefrontContext = createContext<StorefrontContextValue | undefined>(undefined);
const CART_KEY = "whispering-pages-cart";
const WISHLIST_KEY = "whispering-pages-wishlist";

function loadSaved<T>(key: string, fallback: T): T {
  try {
    const value = localStorage.getItem(key);
    return value ? (JSON.parse(value) as T) : fallback;
  } catch {
    return fallback;
  }
}

export function StorefrontProvider({ children }: { children: ReactNode }) {
  const [cart, setCart] = useState<CartItem[]>(() => loadSaved(CART_KEY, []));
  const [wishlist, setWishlist] = useState<Book[]>(() => loadSaved(WISHLIST_KEY, []));

  useEffect(() => localStorage.setItem(CART_KEY, JSON.stringify(cart)), [cart]);
  useEffect(() => localStorage.setItem(WISHLIST_KEY, JSON.stringify(wishlist)), [wishlist]);

  const value = useMemo<StorefrontContextValue>(() => {
    const addToCart = (book: Book) => {
      setCart(current => addCartItem(current, book));
    };
    const removeFromCart = (key: string) => setCart(current => current.filter(entry => entry.book.key !== key));
    const updateQuantity = (key: string, quantity: number) => {
      setCart(current => setCartItemQuantity(current, key, quantity));
    };
    const toggleWishlist = (book: Book) => {
      setWishlist(current => (current.some(entry => entry.key === book.key) ? current.filter(entry => entry.key !== book.key) : [...current, book]));
    };
    return {
      cart,
      wishlist,
      cartCount: cart.reduce((sum, item) => sum + item.quantity, 0),
      subtotal: cartSubtotal(cart),
      addToCart,
      removeFromCart,
      updateQuantity,
      clearCart: () => setCart([]),
      toggleWishlist,
      isWishlisted: key => wishlist.some(book => book.key === key),
    };
  }, [cart, wishlist]);

  return <StorefrontContext.Provider value={value}>{children}</StorefrontContext.Provider>;
}

export function useStorefront() {
  const context = useContext(StorefrontContext);
  if (!context) throw new Error("useStorefront must be used within StorefrontProvider");
  return context;
}
