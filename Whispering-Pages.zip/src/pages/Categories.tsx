import { CATEGORIES } from "@shared/books";
import { ArrowRight, Sparkles } from "lucide-react";
import { Link } from "wouter";

const categoryText: Record<string, string> = {
  Romance: "Heart-forward stories and irresistible chemistry.",
  Mystery: "Clever puzzles, missing clues, and quiet tension.",
  Fantasy: "Magical realms made for disappearing into.",
  Thriller: "High-stakes pages that refuse to sit still.",
  Fiction: "Remarkable lives, intimate moments, lasting ideas.",
  Horror: "A chill down the spine, beautifully written.",
  "Science Fiction": "Brave futures, strange worlds, limitless questions.",
  "Historical Fiction": "The past, vividly and memorably reimagined.",
  "Young Adult": "Big feelings, first choices, unforgettable voices.",
};

export default function Categories() {
  return <div className="container py-12 sm:py-16"><div className="rounded-[2rem] bg-[#35241d] px-6 py-12 text-[#f9e8c5] sm:px-12 sm:py-16"><div className="max-w-2xl"><p className="flex items-center gap-2 text-[11px] font-bold tracking-[0.2em] text-[#d9ae62]"><Sparkles className="size-3" /> FIND YOUR NEXT MOOD</p><h1 className="mt-4 font-display text-5xl leading-tight sm:text-6xl">Categories</h1><p className="mt-5 max-w-xl leading-7 text-[#f9e8c5]/70">Follow a feeling, a fascination, or simply a title you cannot stop thinking about. Every shelf has somewhere to take you.</p></div></div><section className="mt-10"><p className="section-kicker">Browse the shelves</p><h2 className="mt-2 font-display text-3xl">Books by Category</h2><div className="mt-7 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">{CATEGORIES.map((category, index) => <Link key={category} href={`/books?category=${encodeURIComponent(category)}`} className="group relative min-h-[190px] overflow-hidden rounded-2xl border border-border bg-card p-6 transition duration-300 hover:-translate-y-1 hover:border-primary hover:shadow-xl hover:shadow-primary/10"><div className="absolute right-5 top-4 font-display text-6xl italic text-primary/10">0{index + 1}</div><div className="relative flex h-full flex-col justify-between"><div><h3 className="font-display text-2xl">{category}</h3><p className="mt-3 max-w-[250px] text-sm leading-6 text-muted-foreground">{categoryText[category]}</p></div><span className="mt-7 inline-flex items-center gap-2 text-sm font-bold text-primary">Explore {category} <ArrowRight className="size-4 transition group-hover:translate-x-1" /></span></div></Link>)}</div></section></div>;
}
