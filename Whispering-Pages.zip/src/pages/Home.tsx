import BookRail from "@/components/store/BookRail";
import { BookCover } from "@/components/store/BookCard";
import { trpc } from "@/lib/trpc";
import type { Book } from "@shared/books";
import { ArrowRight, BookOpen, Sparkles } from "lucide-react";
import { Link } from "wouter";

function RailLoading() {
  return <div className="flex gap-4 overflow-hidden"><div className="h-[330px] w-[206px] shrink-0 animate-pulse rounded-2xl bg-secondary" /><div className="h-[330px] w-[206px] shrink-0 animate-pulse rounded-2xl bg-secondary" /><div className="h-[330px] w-[206px] shrink-0 animate-pulse rounded-2xl bg-secondary" /></div>;
}

function Collection({ title, eyebrow, books, loading }: { title: string; eyebrow: string; books?: Book[]; loading: boolean }) {
  return <section className="container mt-20"><div className="mb-8 flex items-end justify-between gap-5"><div><p className="section-kicker">{eyebrow}</p><h2 className="mt-2 font-display text-3xl sm:text-4xl">{title}</h2></div><Link href="/books" className="hidden items-center gap-1.5 text-sm font-bold text-primary hover:underline sm:flex">View all <ArrowRight className="size-4" /></Link></div>{loading ? <RailLoading /> : books?.length ? <BookRail books={books} label={title} /> : <p className="rounded-2xl bg-card p-8 text-muted-foreground">The live catalog needs a moment. Please refresh to try again.</p>}</section>;
}

export default function Home() {
  const featured = trpc.books.list.useQuery({ category: "Fiction", limit: 12 });
  const bestSellers = trpc.books.list.useQuery({ category: "Fantasy", limit: 12 });
  const newArrivals = trpc.books.list.useQuery({ category: "Thriller", limit: 12 });
  const heroBook = featured.data?.[0];

  return (
    <>
      <section className="paper-grid border-b border-border/70 bg-secondary/45">
        <div className="container grid min-h-[570px] items-center gap-10 py-14 lg:grid-cols-[1.15fr_0.85fr] lg:py-20">
          <div className="max-w-2xl"><div className="inline-flex items-center gap-2 rounded-full border border-primary/20 bg-background/70 px-3 py-1.5 text-[10px] font-bold tracking-[0.16em] text-primary"><Sparkles className="size-3" /> THE READER&apos;S ROOM</div><h1 className="mt-6 font-display text-5xl leading-[0.98] tracking-[-0.035em] sm:text-6xl lg:text-7xl">A beautifully chosen life, one <i className="text-primary">story</i> at a time.</h1><p className="mt-6 max-w-xl text-base leading-7 text-muted-foreground sm:text-lg">Explore a considered collection of novels, new worlds, and unforgettable voices. Your next favorite book is waiting between these shelves.</p><div className="mt-9 flex flex-wrap gap-3"><Link href="/books" className="inline-flex h-12 items-center gap-2 rounded-xl bg-primary px-5 text-sm font-bold text-primary-foreground shadow-lg shadow-primary/15 transition hover:brightness-110 active:scale-[0.97]">Browse the collection <ArrowRight className="size-4" /></Link><Link href="/categories" className="inline-flex h-12 items-center gap-2 rounded-xl border border-border bg-background/80 px-5 text-sm font-bold transition hover:border-primary hover:text-primary active:scale-[0.97]"><BookOpen className="size-4" /> Explore Categories</Link></div><div className="mt-12 flex items-center gap-8 border-t border-border/75 pt-6"><div><strong className="font-display text-2xl">Stories</strong><p className="text-xs text-muted-foreground">worth staying up for</p></div><div className="h-8 w-px bg-border" /><div><strong className="font-display text-2xl">Live</strong><p className="text-xs text-muted-foreground">catalog discovery</p></div></div></div>
          <div className="relative mx-auto w-full max-w-[420px] py-7 lg:py-0"><div className="absolute inset-8 -rotate-6 rounded-[2rem] bg-primary/15" /><div className="absolute inset-8 rotate-6 rounded-[2rem] border border-primary/20 bg-background/60" />{heroBook ? <div className="relative mx-auto w-[220px] sm:w-[258px]"><BookCover book={heroBook} className="aspect-[2/3] rounded-[1.5rem] shadow-2xl" /><div className="absolute -bottom-5 -left-8 max-w-[190px] rounded-2xl border border-border bg-card/95 p-4 shadow-xl backdrop-blur"><p className="text-[10px] font-bold tracking-[0.16em] text-primary">NOW SHELVING</p><p className="mt-1 font-display text-base leading-tight">{heroBook.title}</p><p className="mt-1 text-xs text-muted-foreground">{heroBook.author}</p></div></div> : <div className="relative mx-auto aspect-[2/3] w-[220px] animate-pulse rounded-[1.5rem] bg-card shadow-2xl sm:w-[258px]" />}</div>
        </div>
      </section>
      <Collection title="Featured Books" eyebrow="Selected with intention" books={featured.data} loading={featured.isLoading} />
      <section className="mt-20 bg-[#35241d] text-[#f9e8c5]"><div className="container grid gap-8 py-16 lg:grid-cols-[1fr_auto]"><div><p className="text-[11px] font-bold tracking-[0.2em] text-[#d9ae62]">THE WHISPERING EDIT</p><h2 className="mt-3 max-w-2xl font-display text-4xl leading-tight sm:text-5xl">Stories that leave the room a little more luminous.</h2></div><Link href="/categories" className="inline-flex h-11 items-center justify-center gap-2 self-center rounded-xl border border-[#f9e8c5]/30 px-5 text-sm font-bold transition hover:bg-[#f9e8c5] hover:text-[#35241d]">Find your genre <ArrowRight className="size-4" /></Link></div></section>
      <Collection title="Best Sellers" eyebrow="Most wanted right now" books={bestSellers.data} loading={bestSellers.isLoading} />
      <Collection title="New Arrivals" eyebrow="Fresh from the shelves" books={newArrivals.data} loading={newArrivals.isLoading} />
    </>
  );
}
