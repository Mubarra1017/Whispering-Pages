import BookCard from "@/components/store/BookCard";
import { useStorefront } from "@/contexts/StorefrontContext";
import { Heart } from "lucide-react";
import { Link } from "wouter";

export default function Wishlist() {
  const { wishlist } = useStorefront();
  return <div className="container py-12 sm:py-16"><p className="section-kicker">Your saved shelf</p><h1 className="mt-2 font-display text-5xl sm:text-6xl">Wishlist</h1><p className="mt-4 max-w-xl text-muted-foreground">Keep the books that caught your attention close by. Your choices stay saved on this device.</p>{wishlist.length ? <div className="mt-10 grid grid-cols-2 gap-x-4 gap-y-9 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5">{wishlist.map(book => <BookCard key={book.key} book={book} />)}</div> : <div className="mt-10 grid min-h-[280px] place-items-center rounded-3xl border border-dashed border-border bg-card p-8 text-center"><div><div className="mx-auto grid size-14 place-items-center rounded-full bg-secondary text-primary"><Heart className="size-6" /></div><h2 className="mt-5 font-display text-3xl">Your Wishlist is waiting</h2><p className="mt-2 text-sm text-muted-foreground">Save a book with the heart icon and it will appear right here.</p><Link href="/books" className="mt-6 inline-flex rounded-xl bg-primary px-5 py-3 text-sm font-bold text-primary-foreground">Browse Book Listing</Link></div></div>}</div>;
}
