import { useMutation, useQuery, useQueryClient, type UseMutationOptions, type UseQueryOptions } from "@tanstack/react-query";
import type { Book } from "@shared/books";
import { categoryForSubjects, priceForBook } from "@shared/books";

type OpenLibraryDocument = {
  key?: string;
  title?: string;
  author_name?: string[];
  author_key?: string[];
  cover_i?: number;
  first_publish_year?: number;
  subject?: string[];
  ratings_average?: number;
  ratings_count?: number;
  want_to_read_count?: number;
  already_read_count?: number;
  description?: string | { value?: string };
  covers?: number[];
  subjects?: string[];
  first_publish_date?: string;
  authors?: Array<{ author?: { key?: string } }>;
};

const API = "https://openlibrary.org";
const memory = new Map<string, { expires: number; value: unknown }>();
const TEN_MINUTES = 10 * 60 * 1000;

function cached<T>(key: string): T | undefined {
  const item = memory.get(key);
  if (!item || item.expires < Date.now()) {
    memory.delete(key);
    return undefined;
  }
  return item.value as T;
}

function setCached<T>(key: string, value: T): T {
  memory.set(key, { expires: Date.now() + TEN_MINUTES, value });
  return value;
}

function toBook(doc: OpenLibraryDocument): Book | null {
  const rawKey = doc.key?.replace("/works/", "");
  if (!rawKey || !doc.title) return null;
  const subjects = (doc.subject ?? []).slice(0, 18);
  const rating = typeof doc.ratings_average === "number" ? Number(doc.ratings_average.toFixed(1)) : null;
  const ratingCount = doc.ratings_count ?? 0;
  return {
    key: rawKey,
    title: doc.title,
    author: doc.author_name?.[0] ?? "Unknown author",
    authorKey: doc.author_key?.[0],
    coverUrl: doc.cover_i ? `https://covers.openlibrary.org/b/id/${doc.cover_i}-L.jpg` : null,
    category: categoryForSubjects(subjects),
    subjects,
    firstPublished: doc.first_publish_year ?? null,
    rating,
    ratingCount,
    popularity: ratingCount || (doc.want_to_read_count ?? 0) + (doc.already_read_count ?? 0),
    price: priceForBook(rawKey),
  };
}

async function searchBooks(input: { query?: string; category?: string; limit?: number } = {}): Promise<Book[]> {
  const query = input.query?.trim();
  const category = input.category?.trim();
  const limit = Math.min(Math.max(input.limit ?? 18, 1), 40);
  const key = `list:${JSON.stringify({ query, category, limit })}`;
  const hit = cached<Book[]>(key);
  if (hit) return hit;
  const terms = query || (category ? `subject:${category}` : "subject:Fiction");
  const params = new URLSearchParams({
    q: terms,
    limit: String(limit),
    fields: "key,title,author_name,author_key,cover_i,first_publish_year,subject,ratings_average,ratings_count,want_to_read_count,already_read_count",
  });
  const response = await fetch(`${API}/search.json?${params}`);
  if (!response.ok) throw new Error(`The live catalog is temporarily unavailable (${response.status}).`);
  const data = await response.json() as { docs?: OpenLibraryDocument[] };
  return setCached(key, (data.docs ?? []).map(toBook).filter((book): book is Book => Boolean(book)));
}

async function getBookDetails(key: string): Promise<Book> {
  const safeKey = key.replace(/[^A-Za-z0-9]/g, "");
  if (!safeKey) throw new Error("This book could not be found.");
  const cacheKey = `detail:${safeKey}`;
  const hit = cached<Book>(cacheKey);
  if (hit) return hit;

  const workResponse = await fetch(`${API}/works/${safeKey}.json`);
  if (!workResponse.ok) throw new Error("This book could not be found.");
  const work = await workResponse.json() as OpenLibraryDocument;
  const searchResult = await searchBooks({ query: safeKey, limit: 1 }).catch(() => []);
  const sourceBook = searchResult[0];
  const authorKey = sourceBook?.authorKey ?? work.authors?.[0]?.author?.key?.replace("/authors/", "");
  let authorBio: string | null = null;
  let authorName = sourceBook?.author ?? "Unknown author";

  if (authorKey) {
    try {
      const response = await fetch(`${API}/authors/${authorKey}.json`);
      if (response.ok) {
        const author = await response.json() as { name?: string; bio?: string | { value?: string } };
        authorName = author.name ?? authorName;
        authorBio = typeof author.bio === "string" ? author.bio : author.bio?.value ?? null;
      }
    } catch {}
  }

  const description = typeof work.description === "string" ? work.description : work.description?.value ?? null;
  const subjects = work.subjects ?? sourceBook?.subjects ?? [];
  return setCached(cacheKey, {
    key: safeKey,
    title: work.title ?? sourceBook?.title ?? "Untitled work",
    author: authorName,
    authorKey,
    coverUrl: work.covers?.[0] ? `https://covers.openlibrary.org/b/id/${work.covers[0]}-L.jpg` : sourceBook?.coverUrl ?? null,
    category: categoryForSubjects(subjects),
    subjects: subjects.slice(0, 18),
    description,
    authorBio,
    firstPublished: work.first_publish_date ? Number.parseInt(work.first_publish_date, 10) || null : sourceBook?.firstPublished ?? null,
    rating: sourceBook?.rating ?? null,
    ratingCount: sourceBook?.ratingCount ?? 0,
    popularity: sourceBook?.popularity ?? 0,
    price: priceForBook(safeKey),
  });
}

type QueryOpts<T> = Omit<UseQueryOptions<T, Error>, "queryKey" | "queryFn">;

function listQuery(input?: { query?: string; category?: string; limit?: number }, options?: QueryOpts<Book[]>) {
  return useQuery({ queryKey: ["books", "list", input ?? {}], queryFn: () => searchBooks(input), ...options });
}
function getQuery(input: { key: string }, options?: QueryOpts<Book>) {
  return useQuery({ queryKey: ["books", "get", input.key], queryFn: () => getBookDetails(input.key), ...options });
}

export const trpc = {
  books: {
    list: { useQuery: listQuery },
    get: { useQuery: getQuery },
  },
  auth: {
    me: { useQuery: (_input?: undefined, options?: QueryOpts<null>) => useQuery({ queryKey: ["auth", "me"], queryFn: async () => null, ...options }) },
    logout: { useMutation: (options?: UseMutationOptions<{ success: true }, Error, void>) => useMutation({ mutationFn: async () => ({ success: true as const }), ...options }) },
  },
  ai: {
    chat: { useMutation: (options?: UseMutationOptions<string, Error, { messages: Array<{ role: string; content: string }> }>) => useMutation({
      mutationFn: async () => "AI chat is not available in the static GitHub Pages version.",
      ...options,
    }) },
  },
  useUtils: () => {
    const client = useQueryClient();
    return {
      auth: {
        me: {
          setData: (_input: undefined, data: null) => client.setQueryData(["auth", "me"], data),
          invalidate: () => client.invalidateQueries({ queryKey: ["auth", "me"] }),
        },
      },
    };
  },
};
