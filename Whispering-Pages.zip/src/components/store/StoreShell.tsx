import { useTheme } from "@/contexts/ThemeContext";
import { useStorefront } from "@/contexts/StorefrontContext";
import { Heart, Menu, Moon, Search, ShoppingBag, Sun, X } from "lucide-react";
import { useEffect, useState, type ReactNode } from "react";
import { Link, useLocation } from "wouter";

const navItems = [
  ["Home Page", "/"],
  ["Book Listing", "/books"],
  ["Categories", "/categories"],
] as const;

export default function StoreShell({ children }: { children: ReactNode }) {
  const { theme, toggleTheme } = useTheme();
  const { cartCount, wishlist } = useStorefront();
  const [location, setLocation] = useLocation();
  const [menuOpen, setMenuOpen] = useState(false);
  const [search, setSearch] = useState("");

  useEffect(() => setMenuOpen(false), [location]);
  useEffect(() => {
    const term = window.setTimeout(() => {
      if (search.trim()) setLocation(`/books?search=${encodeURIComponent(search.trim())}`);
    }, 350);
    return () => window.clearTimeout(term);
  }, [search, setLocation]);

  return (
    <div className="min-h-screen overflow-x-hidden bg-background text-foreground">
      <div className="hidden border-b border-border/80 bg-[#35241d] px-4 py-2 text-center text-[11px] font-semibold tracking-[0.12em] text-[#f9e8c5] sm:block">CURATED STORIES, THOUGHTFULLY DELIVERED</div>
      <header className="sticky top-0 z-40 border-b border-border/70 bg-background/90 backdrop-blur-xl">
        <div className="container flex h-[74px] items-center justify-between gap-4">
          <Link href="/" className="group flex shrink-0 items-center gap-2.5" aria-label="Whispering Pages home">
            <span className="grid size-9 place-items-center rounded-xl bg-primary font-display text-xl text-primary-foreground shadow-sm transition group-hover:rotate-[-4deg]">W</span>
            <span className="hidden font-display text-xl tracking-tight sm:block">Whispering <span className="text-primary">Pages</span></span>
          </Link>
          <nav className="hidden items-center gap-7 lg:flex" aria-label="Primary navigation">
            {navItems.map(([label, href]) => <Link key={href} href={href} className={`text-sm font-semibold transition hover:text-primary ${location === href ? "text-primary" : "text-muted-foreground"}`}>{label}</Link>)}
          </nav>
          <div className="hidden max-w-[270px] flex-1 md:block">
            <label className="relative block">
              <span className="sr-only">Live search by title or author</span>
              <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
              <input value={search} onChange={event => setSearch(event.target.value)} placeholder="Search title or author" className="h-10 w-full rounded-full border border-border bg-card pl-9 pr-4 text-sm outline-none transition focus:border-primary focus:ring-2 focus:ring-primary/15" />
            </label>
          </div>
          <div className="flex items-center gap-1 sm:gap-2">
            <button type="button" onClick={toggleTheme} className="grid size-9 place-items-center rounded-full text-muted-foreground transition hover:bg-accent hover:text-foreground" aria-label={`Switch to ${theme === "light" ? "dark" : "light"} mode`}>
              {theme === "light" ? <Moon className="size-4" /> : <Sun className="size-4" />}
            </button>
            <Link href="/wishlist" className="relative grid size-9 place-items-center rounded-full text-muted-foreground transition hover:bg-accent hover:text-foreground" aria-label="Wishlist">
              <Heart className="size-4" />
              {wishlist.length ? <span className="absolute -right-1 -top-1 grid size-4 place-items-center rounded-full bg-primary text-[9px] font-bold text-primary-foreground">{wishlist.length}</span> : null}
            </Link>
            <Link href="/cart" className="relative grid size-9 place-items-center rounded-full text-muted-foreground transition hover:bg-accent hover:text-foreground" aria-label="Shopping Cart">
              <ShoppingBag className="size-4" />
              {cartCount ? <span className="absolute -right-1 -top-1 grid size-4 place-items-center rounded-full bg-primary text-[9px] font-bold text-primary-foreground">{cartCount}</span> : null}
            </Link>
            <button type="button" onClick={() => setMenuOpen(open => !open)} className="grid size-9 place-items-center rounded-full text-muted-foreground transition hover:bg-accent lg:hidden" aria-label={menuOpen ? "Close navigation menu" : "Open navigation menu"}>
              {menuOpen ? <X className="size-5" /> : <Menu className="size-5" />}
            </button>
          </div>
        </div>
        {menuOpen ? <div className="border-t border-border bg-background px-4 py-5 lg:hidden"><nav className="container flex flex-col gap-4" aria-label="Mobile navigation">{navItems.map(([label, href]) => <Link key={href} href={href} className="font-display text-xl">{label}</Link>)}<Link href="/wishlist" className="font-display text-xl">Wishlist</Link><div className="mt-1 md:hidden"><label className="relative block"><Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" /><input value={search} onChange={event => setSearch(event.target.value)} placeholder="Search title or author" className="h-11 w-full rounded-full border border-border bg-card pl-9 pr-4 text-sm outline-none" /></label></div></nav></div> : null}
      </header>
      <main>{children}</main>
      <footer className="mt-20 border-t border-border bg-card">
        <div className="container grid gap-10 py-12 sm:grid-cols-[1.3fr_1fr_1fr]">
          <div><div className="font-display text-2xl">Whispering <span className="text-primary">Pages</span></div><p className="mt-3 max-w-sm text-sm leading-6 text-muted-foreground">An independent-minded online bookstore for readers who keep a little room in every day for a good story.</p></div>
          <div><h2 className="text-xs font-bold tracking-[0.17em] text-primary">DISCOVER</h2><div className="mt-4 grid gap-2 text-sm text-muted-foreground"><Link href="/books">Book Listing</Link><Link href="/categories">Categories</Link><Link href="/wishlist">Wishlist</Link></div></div>
          <div><h2 className="text-xs font-bold tracking-[0.17em] text-primary">A NOTE ON PRICING</h2><p className="mt-4 text-sm leading-6 text-muted-foreground">Catalog details are supplied by Open Library. Prices are presented for this interactive storefront experience.</p></div>
        </div>
      </footer>
    </div>
  );
}
