import type { Book } from "@shared/books";
import { ArrowLeft, ArrowRight } from "lucide-react";
import { useRef } from "react";
import BookCard from "./BookCard";

export default function BookRail({ books, label }: { books: Book[]; label: string }) {
  const railRef = useRef<HTMLDivElement>(null);
  const scroll = (direction: "left" | "right") => railRef.current?.scrollBy({ left: direction === "left" ? -560 : 560, behavior: "smooth" });
  return (
    <div className="relative">
      <div className="absolute right-0 -top-14 hidden items-center gap-2 sm:flex">
        <button type="button" aria-label={`Previous ${label} books`} onClick={() => scroll("left")} className="grid size-9 place-items-center rounded-full border border-border bg-background transition hover:border-primary hover:text-primary"><ArrowLeft className="size-4" /></button>
        <button type="button" aria-label={`Next ${label} books`} onClick={() => scroll("right")} className="grid size-9 place-items-center rounded-full border border-border bg-background transition hover:border-primary hover:text-primary"><ArrowRight className="size-4" /></button>
      </div>
      <div ref={railRef} className="-mx-4 flex snap-x snap-mandatory gap-4 overflow-x-auto px-4 pb-5 pt-1 [scrollbar-width:none] sm:-mx-6 sm:px-6 lg:-mx-8 lg:px-8">
        {books.map(book => <div key={book.key} className="snap-start"><BookCard book={book} compact /></div>)}
      </div>
    </div>
  );
}
