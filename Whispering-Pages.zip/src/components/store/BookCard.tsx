import type { Book } from "@shared/books";
import { Heart, ShoppingBag, Star } from "lucide-react";
import { Link } from "wouter";
import { useStorefront } from "@/contexts/StorefrontContext";
import { cn } from "@/lib/utils";
import { toast } from "sonner";
import { useState } from "react";

type BookCardProps = {
  book: Book;
  compact?: boolean;
};

export function BookCover({ book, className }: { book: Book; className?: string }) {
  const [imageFailed, setImageFailed] = useState(!book.coverUrl);
  const coverAvailable = Boolean(book.coverUrl) && !imageFailed;
  return (
    <div className={cn("book-cover relative overflow-hidden bg-[#e8dfd1] dark:bg-[#44362d]", className)}>
      {coverAvailable ? (
        <img
          src={book.coverUrl ?? undefined}
          alt={`Cover of ${book.title}`}
          className="h-full w-full object-cover transition duration-500 group-hover:scale-[1.045]"
          loading="lazy"
          onError={() => setImageFailed(true)}
        />
      ) : null}
      {!coverAvailable ? <div className="absolute inset-0 flex flex-col justify-between bg-[linear-gradient(145deg,#d9bd93_0%,#9e6549_100%)] p-4 text-[#fff8e9]"><span className="text-[9px] font-bold tracking-[0.17em] opacity-80">WHISPERING PAGES</span><span className="font-display text-lg leading-tight drop-shadow-sm">{book.title}</span><span className="text-xs opacity-85">{book.author}</span></div> : null}
      <div className="absolute inset-0 flex items-end p-4 pointer-events-none">
        <span className="font-display text-lg leading-tight text-[#4a3429] dark:text-[#f7e9d3] drop-shadow-sm">{coverAvailable ? "" : ""}</span>
      </div>
    </div>
  );
}

export default function BookCard({ book, compact = false }: BookCardProps) {
  const { addToCart, isWishlisted, toggleWishlist } = useStorefront();
  const wished = isWishlisted(book.key);
  const add = () => {
    addToCart(book);
    toast.success(`${book.title} added to Shopping Cart`);
  };

  return (
    <article className={cn("group relative flex min-w-0 flex-col", compact ? "w-[206px] sm:w-[224px]" : "w-full")}>
      <div className="relative">
        <Link href={`/book/${encodeURIComponent(book.key)}`} className="block focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-4 rounded-[1.15rem]">
          <BookCover book={book} className={cn("rounded-[1.15rem] shadow-[0_16px_30px_-18px_rgba(48,33,24,0.75)] transition duration-300 group-hover:-translate-y-1 group-hover:shadow-[0_22px_32px_-18px_rgba(48,33,24,0.78)]", compact ? "aspect-[2/3]" : "aspect-[2/3]")} />
        </Link>
        <button
          type="button"
          aria-label={wished ? `Remove ${book.title} from Wishlist` : `Add ${book.title} to Wishlist`}
          onClick={() => toggleWishlist(book)}
          className={cn("absolute right-3 top-3 grid size-9 place-items-center rounded-full bg-background/95 shadow-sm backdrop-blur transition hover:scale-105 active:scale-95", wished && "text-[#b44054]")}
        >
          <Heart className={cn("size-4", wished && "fill-current")} />
        </button>
      </div>
      <div className="flex flex-1 flex-col pt-4">
        <span className="mb-1 text-[10px] font-bold uppercase tracking-[0.17em] text-primary">{book.category}</span>
        <Link href={`/book/${encodeURIComponent(book.key)}`} className="font-display line-clamp-2 text-[1.12rem] leading-[1.18] hover:text-primary">{book.title}</Link>
        <p className="mt-1 truncate text-sm text-muted-foreground">{book.author}</p>
        <div className="mt-3 flex items-center justify-between gap-2">
          <div className="flex min-w-0 items-center gap-1 text-xs text-muted-foreground">
            <Star className={cn("size-3.5", book.rating ? "fill-[#c8903a] text-[#c8903a]" : "text-muted-foreground/50")} />
            {book.rating ? <span className="font-semibold text-foreground">{book.rating.toFixed(1)}</span> : <span>Unrated</span>}
            {book.ratingCount > 0 ? <span className="truncate">({book.ratingCount.toLocaleString()})</span> : null}
          </div>
          <span className="font-semibold text-foreground">${book.price.toFixed(2)}</span>
        </div>
        {!compact ? (
          <button type="button" onClick={add} className="mt-4 inline-flex h-10 items-center justify-center gap-2 rounded-xl bg-primary px-4 text-sm font-semibold text-primary-foreground transition hover:brightness-110 active:scale-[0.97]">
            <ShoppingBag className="size-4" />
            Add to Cart
          </button>
        ) : null}
      </div>
    </article>
  );
}
