import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Router as WouterRouter, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import StoreShell from "./components/store/StoreShell";
import { ThemeProvider } from "./contexts/ThemeContext";
import { StorefrontProvider } from "./contexts/StorefrontContext";
import Categories from "./pages/Categories";
import Cart from "./pages/Cart";
import Checkout from "./pages/Checkout";
import BookDetails from "./pages/BookDetails";
import BookListing from "./pages/BookListing";
import Home from "./pages/Home";
import Wishlist from "./pages/Wishlist";

function Router() {
  // make sure to consider if you need authentication for certain routes
  return (
    <WouterRouter base={import.meta.env.BASE_URL}>
      <StoreShell>
        <Switch>
        <Route path={"/"} component={Home} />
        <Route path={"/books"} component={BookListing} />
        <Route path={"/categories"} component={Categories} />
        <Route path={"/book/:key"}>{params => <BookDetails bookKey={params.key} />}</Route>
        <Route path={"/wishlist"} component={Wishlist} />
        <Route path={"/cart"} component={Cart} />
        <Route path={"/checkout"} component={Checkout} />
        <Route path={"/404"} component={NotFound} />
        <Route component={NotFound} />
        </Switch>
      </StoreShell>
    </WouterRouter>
  );
}

// NOTE: About Theme
// - First choose a default theme according to your design style (dark or light bg), than change color palette in index.css
//   to keep consistent foreground/background color across components
// - If you want to make theme switchable, pass `switchable` ThemeProvider and use `useTheme` hook

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider
        defaultTheme="light"
        switchable
      >
        <StorefrontProvider>
          <TooltipProvider>
            <Toaster />
            <Router />
          </TooltipProvider>
        </StorefrontProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
