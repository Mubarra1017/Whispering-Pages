import type { Book } from "./books";

export type CartItem = { book: Book; quantity: number };

export function addCartItem(cart: CartItem[], book: Book): CartItem[] {
  const existing = cart.find(item => item.book.key === book.key);
  return existing
    ? cart.map(item => (item.book.key === book.key ? { ...item, quantity: item.quantity + 1 } : item))
    : [...cart, { book, quantity: 1 }];
}

export function setCartItemQuantity(cart: CartItem[], key: string, quantity: number): CartItem[] {
  return cart.flatMap(item => (item.book.key !== key ? [item] : quantity > 0 ? [{ ...item, quantity }] : []));
}

export function cartSubtotal(cart: CartItem[]): number {
  return Number(cart.reduce((sum, item) => sum + item.book.price * item.quantity, 0).toFixed(2));
}
