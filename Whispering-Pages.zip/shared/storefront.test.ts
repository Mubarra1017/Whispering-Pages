import { describe, expect, it } from "vitest";
import { filterAndSortBooks, type Book } from "./books";
import { addCartItem, cartSubtotal, setCartItemQuantity } from "./cart";

const books: Book[] = [
  { key: "a", title: "A", author: "One", coverUrl: null, category: "Fiction", subjects: [], rating: 4.8, ratingCount: 100, popularity: 900, price: 18.5 },
  { key: "b", title: "B", author: "Two", coverUrl: null, category: "Fantasy", subjects: [], rating: 4.2, ratingCount: 10, popularity: 500, price: 12.25 },
  { key: "c", title: "C", author: "Three", coverUrl: null, category: "Mystery", subjects: [], rating: null, ratingCount: 0, popularity: 100, price: 26 },
];

describe("catalog filtering and sorting", () => {
  it("keeps books inside the selected price and rating ranges", () => {
    expect(filterAndSortBooks(books, { maxPrice: 20, minRating: 4 })).toEqual([books[0], books[1]]);
  });

  it("sorts the visible books by price when requested", () => {
    expect(filterAndSortBooks(books, { sort: "price-low" }).map(book => book.key)).toEqual(["b", "a", "c"]);
  });
});

describe("Shopping Cart calculations", () => {
  it("increments matching items, updates quantities, and calculates subtotal", () => {
    const afterAdding = addCartItem(addCartItem([], books[0]), books[0]);
    const cart = setCartItemQuantity([...afterAdding, { book: books[1], quantity: 2 }], "a", 3);
    expect(cart).toEqual([{ book: books[0], quantity: 3 }, { book: books[1], quantity: 2 }]);
    expect(cartSubtotal(cart)).toBe(80);
  });

  it("removes an item when the selected quantity reaches zero", () => {
    expect(setCartItemQuantity([{ book: books[0], quantity: 1 }], "a", 0)).toEqual([]);
  });
});
