export const CATEGORIES = [
  "Romance",
  "Mystery",
  "Fantasy",
  "Thriller",
  "Fiction",
  "Horror",
  "Science Fiction",
  "Historical Fiction",
  "Young Adult",
] as const;

export type Category = (typeof CATEGORIES)[number];

export type Book = {
  key: string;
  title: string;
  author: string;
  authorKey?: string;
  coverUrl: string | null;
  category: string;
  subjects: string[];
  description?: string | null;
  authorBio?: string | null;
  firstPublished?: number | null;
  rating: number | null;
  ratingCount: number;
  popularity: number;
  price: number;
};

export type CatalogSort = "popular" | "rating" | "price-low" | "price-high";

export type CatalogFilters = {
  minPrice?: number;
  maxPrice?: number;
  minRating?: number;
  sort?: CatalogSort;
};

export function priceForBook(key: string): number {
  const code = Array.from(key).reduce((total, character) => total + character.charCodeAt(0), 0);
  return Number((12 + (code % 1800) / 100).toFixed(2));
}

export function categoryForSubjects(subjects: string[] = []): string {
  const haystack = subjects.join(" ").toLowerCase();
  const match = CATEGORIES.find(category => haystack.includes(category.toLowerCase()));
  return match ?? "Fiction";
}

export function filterAndSortBooks(books: Book[], filters: CatalogFilters = {}): Book[] {
  const { minPrice = 0, maxPrice = Number.POSITIVE_INFINITY, minRating = 0, sort = "popular" } = filters;
  const visible = books.filter(book => {
    const rating = book.rating ?? 0;
    return book.price >= minPrice && book.price <= maxPrice && rating >= minRating;
  });

  return [...visible].sort((a, b) => {
    if (sort === "price-low") return a.price - b.price;
    if (sort === "price-high") return b.price - a.price;
    if (sort === "rating") return (b.rating ?? -1) - (a.rating ?? -1);
    return b.popularity - a.popularity;
  });
}
